#!/bin/sh

GREETING="Hello!"

echo ${GREETING}
